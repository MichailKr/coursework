# coursework

Для того чтобы запустить игру,
загрузите библиотеки pygame и pytmx и запустите main
