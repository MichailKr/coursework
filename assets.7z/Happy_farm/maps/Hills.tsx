<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Hills" tilewidth="32" tileheight="32" margin="6" tilecount="15" columns="5">
 <image source="Hills.png" width="176" height="112"/>
</tileset>
