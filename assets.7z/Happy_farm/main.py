from src.game_manager import GameManager

def main():
    game = GameManager()
    game.run()

if __name__ == "__main__":
    main()
